document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to Sorteos Muy Locos!');
    alert('¡Gracias por visitar nuestra página! Explora nuestros productos y participa en los sorteos.');
});
